#!/bin/bash

export FFTW_LIB=fftw-3.3.3

#
#END-OF-FILE
#



